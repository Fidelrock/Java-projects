/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package university.management.system;

/**
 *
 * @author fidel
 */
import javax.swing.*;
import java.awt.*;

public class TestClass {
    public static void main(String s[]){
//         new UserLogin();
     
        
//        Frame f = new Frame("Telville University"); 
//        f.setVisible(true); 
//        int i;
//        int x=1;
//        for(i=2;i<=600;i+=4,x+=1){
//            f.setLocation((800-((i+x)/2) ),500-(i/2));
//            f.setSize(i+3*x,i+x/2);
//            
//            try{
//                Thread.sleep(10);
//            }catch(Exception e) { }
//        }
         //new Project().setVisible(true);
         new AboutUs().setVisible(true);
    }
    
}
