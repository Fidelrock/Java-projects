package com.example.unitTestingTutorial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UnitTestingTutorialApplicationTests {

	@Test
	void contextLoads() {
	}

}
